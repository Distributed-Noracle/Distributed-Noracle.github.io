java -cp "lib/*" i5.las2peer.tools.L2pNodeLauncher
